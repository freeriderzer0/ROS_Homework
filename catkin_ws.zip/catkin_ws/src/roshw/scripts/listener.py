#!/usr/bin/env python
# Software License Agreement (BSD License)
#
# Copyright (c) 2008, Willow Garage, Inc.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following
#    disclaimer in the documentation and/or other materials provided
#    with the distribution.
#  * Neither the name of Willow Garage, Inc. nor the names of its
#    contributors may be used to endorse or promote products derived
#    from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#
# Revision $Id$

## Simple talker demo that listens to std_msgs/Strings published 
## to the 'chatter' topic

import rospy
import math
import numpy as np
from geometry_msgs.msg import Twist
from geometry_msgs.msg import Pose2D
V=0
Omega=0
w_l = [0]*20 
w_r = [0]*20
Theta1 = [0]
X=[0] * 20
Y=[0] * 20
s=0

def callback(data):
    global V
    global Omega
    global w_l
    global w_r
    if V!=data.linear.x or Omega!=data.angular.z:
	V=data.linear.x
	Omega=data.angular.z
	global L
	r = 33
	L = 287
	w_r_target = (2*V + L*Omega)/(2*r)
	w_l_target = ((2*V + L*Omega)/(2*r))-L*Omega/r
	B = 30/(20 + 30) 
	for i in range(1,20):
  	    w_l[i]=w_l[i-1] * B + (1-B) * w_l_target
  	    w_r[i]=w_r[i-1] * B + (1-B) * w_r_target
	dE_l=(np.array(w_l)*20*4096)/(2*math.pi)
	dE_r=(np.array(w_r)*20*4096)/(2*math.pi)
	O = []
	for i in range(len(w_l)):
  	    O.append(0.115 * (w_r[i] - w_l[i]))
	V1 = [0] * 20
	for i in range(len(w_l)):
  	    V1[i] = (r/2) * (w_l[i] + w_r[i])
	h = 0.02
	global Theta1
	global s
	for i in range(len(O)):
  	    summa = s + sum(O[0:i+1])
  	    t = h * summa
  	    Theta1.append(t)
	global X
	global Y
	for i in range(1,len(O)):
  	    X[i]=X[i-1]+V1[i]*math.cos(Theta1[i])
	for i in range(1,len(O)):
  	    Y[i]=Y[i-1]+V1[i]*math.sin(Theta1[i])
	for i in range(20):
	    pose = Pose2D()
	    pose.x = X[i]
    	    pose.y = Y[i]
    	    pose.theta = Theta1[i]
            rospy.loginfo(pose)
	    global pub
            pub.publish(pose)
	w_l = [w_l[19]]*20 
	w_r = [w_r[19]]*20
	Theta1=[Theta1[19]]
	X = [X[19]]*20
	Y = [Y[19]]*20
	s=sum(O)


    #rospy.loginfo(rospy.get_caller_id() + 'I heard %s', data.data)

def listener():

    # In ROS, nodes are uniquely named. If two nodes with the same
    # name are launched, the previous one is kicked off. The
    # anonymous=True flag means that rospy will choose a unique
    # name for our 'listener' node so that multiple listeners can
    # run simultaneously.
    rospy.init_node('listener', anonymous=True)

    rospy.Subscriber('cmd_vel', Twist, callback)
    global pub
    
    pub = rospy.Publisher('chatter', Pose2D, queue_size=10)
    

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

if __name__ == '__main__':
    listener()
